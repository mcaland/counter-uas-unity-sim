# Changelog

## [1.1.0] - 2023-01-24
- Support higher voxel resolutions

## [1.0.0] - 2022-08-16
- Initial release